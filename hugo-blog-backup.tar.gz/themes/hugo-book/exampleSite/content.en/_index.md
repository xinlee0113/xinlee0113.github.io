---
title: Introduction
bookHeadingAnchor: false
layout: landing
---

<div class="book-hero">

# HUGO BOOK
[Hugo](https://gohugo.io) documentation theme as simple as plain book

{{< badge style="info" title="Badge" value="Value" >}} {{< badge style="default" title="Badge" value="Value" >}}

{{<button relref="/docs/example">}}Button{{</button>}}

</div>

{{% columns %}}
- ## Astris ipse furtiva
  Est in vagis et Pittheus tu arge accipiter regia iram vocatur nurus. Omnes ut
  olivae sensit **arma sorori** deducit, inesset **crudus**, ego vetuere aliis,
  modo arsit? Utinam rapta fiducia valuere litora _adicit cursu_, ad facies

- ## Suis quot vota
  Ea _furtique_ risere fratres edidit terrae magis. Colla tam mihi tenebat:
  miseram excita suadent es pecudes iam. Concilio _quam_ velatus posset ait quod
  nunc! Fragosis suae dextra geruntur functus vulgata.
{{% /columns %}}


{{% columns %}}
- {{< card title="Card" image="" >}}
  # Heading
  Nullam feugiat urna massa, et fringilla metus consectetur molestie. Suspendisse sed congue orci, eu congue metus.
  {{< /card >}}

- {{< card title="Card" image="" >}}
  # Heading
  Suspendisse sed congue orci, eu congue metus. Nullam feugiat urna massa, et fringilla metus consectetur molestie.
  {{< /card >}}

- {{< card title="Card" image="" >}}
  # Heading
  Suspendisse sed congue orci, eu congue metus. Nullam feugiat urna massa, et fringilla metus consectetur molestie.
  {{< /card >}}
{{% /columns %}}

{{% columns %}}
- {{< card title="Card" >}}
  ### Heading
  Nullam feugiat urna massa, et fringilla metus consectetur molestie. Suspendisse sed congue orci, eu congue metus.
  {{< /card >}}

- {{< card title="Card" >}}
  ### Heading
  Suspendisse sed congue orci, eu congue metus. Nullam feugiat urna massa, et fringilla metus consectetur molestie.
  {{< /card >}}

- {{< card title="Card" >}}
  ### Heading
  Nullam feugiat urna massa, et fringilla metus consectetur molestie. Suspendisse sed congue orci, eu congue metus.
  {{< /card >}}
{{% /columns %}}
